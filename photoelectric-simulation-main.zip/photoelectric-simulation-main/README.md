# photoelectric-simulation
Hubungan Frekuensi Cahaya dan Energi Kinetik Elektron
