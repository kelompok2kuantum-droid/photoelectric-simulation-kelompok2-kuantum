const h = 4.136e-15

let freq = document.getElementById("freq")
let freqText = document.getElementById("freqText")

freq.oninput = function(){
freqText.innerHTML = this.value + " ×10¹⁴ Hz"
}

let chart = new Chart(document.getElementById("graph"),{

type:"line",

data:{
labels:[],
datasets:[{
label:"Energi Elektron (eV)",
data:[],
borderColor:"blue",
borderWidth:3
}]
}

})

function runSimulation(){

let f = freq.value * 1e14

let phi = document.getElementById("metal").value

let Ek = (h * f) - phi

if(Ek <= 0){

document.getElementById("energy").innerHTML = "0 eV"

document.getElementById("status").innerHTML = "Frekuensi terlalu kecil, elektron tidak keluar"

}else{

document.getElementById("energy").innerHTML = Ek.toFixed(2) + " eV"

document.getElementById("status").innerHTML = "Elektron keluar dari logam"

}

chart.data.labels.push(freq.value)

chart.data.datasets[0].data.push(Ek > 0 ? Ek : 0)

chart.update()

}
